﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            string difficulty = comboBox1.SelectedItem.ToString();
            if (difficulty != null)
            {
                switch (difficulty)
                {
                    case "Easy": Shareddata.time = 70; break;
                    case "Medium": Shareddata.time = 60; break;
                    case "Hard": Shareddata.time = 40; break;
                }
                Shareddata.minNumber = Convert.ToInt32(minTb.Text);
                Shareddata.maxNumber = Convert.ToInt32(maxTb.Text);

            }
            Form2 f2 = new Form2();
            this.Hide();
            f2.ShowDialog();
            this.Close();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
