﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task5
{
    public partial class Form2 : Form
    {
        
        int answer;
        public Form2()
        {
            InitializeComponent();
        }
        /// <summary>
        /// timer to make the countdown label function
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            int newTime = Convert.ToInt32(timerLabel.Text);
            newTime -= 1;
            timerLabel.Text = newTime.ToString();
        }
        /// <summary>
        /// starts the countdown, creates the answer and starts both timers
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void startButton_Click(object sender, EventArgs e)
        {
    
                timerLabel.Text = Shareddata.time.ToString();
                timer1.Start();
                timer2.Interval = Shareddata.time * 1000;
                timer2.Start();
                Random x = new Random();
                answer = x.Next(Shareddata.minNumber, Shareddata.maxNumber);
                
          
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            MessageBox.Show("TIMES UP!\nYou have lost!");    
            timer1.Stop();
        }

        private void menuButton_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            this.Hide();
            form.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int guessedNumber = Convert.ToInt32(guessTb.Text);
            if (guessedNumber < answer)
            { clueTb.Text = "Guess higher..."; }
            else if (guessedNumber > answer)
            { clueTb.Text = "Guess lower..."; }
            else
            {
                timer2.Stop();
                timer1.Stop();
                MessageBox.Show("You have won!");
            }

        }
    }
}
