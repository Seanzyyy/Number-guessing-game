﻿namespace Task5
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            timerLabel = new Label();
            label1 = new Label();
            label2 = new Label();
            guessTb = new TextBox();
            clueTb = new TextBox();
            startButton = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            timer2 = new System.Windows.Forms.Timer(components);
            menuButton = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // timerLabel
            // 
            timerLabel.AutoSize = true;
            timerLabel.Font = new Font("MS Reference Sans Serif", 26F, FontStyle.Bold, GraphicsUnit.Point, 0);
            timerLabel.Location = new Point(142, 38);
            timerLabel.Name = "timerLabel";
            timerLabel.Size = new Size(53, 65);
            timerLabel.TabIndex = 0;
            timerLabel.Text = "-";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(110, 110);
            label1.Name = "label1";
            label1.Size = new Size(148, 25);
            label1.TabIndex = 1;
            label1.Text = "Enter your guess:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(142, 9);
            label2.Name = "label2";
            label2.Size = new Size(86, 29);
            label2.TabIndex = 2;
            label2.Text = "Timer";
            // 
            // guessTb
            // 
            guessTb.Location = new Point(110, 138);
            guessTb.Name = "guessTb";
            guessTb.Size = new Size(148, 31);
            guessTb.TabIndex = 3;
            // 
            // clueTb
            // 
            clueTb.BackColor = SystemColors.GradientInactiveCaption;
            clueTb.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            clueTb.Location = new Point(15, 239);
            clueTb.Name = "clueTb";
            clueTb.Size = new Size(358, 37);
            clueTb.TabIndex = 4;
            clueTb.Text = "Lets see...";
            clueTb.TextAlign = HorizontalAlignment.Center;
            // 
            // startButton
            // 
            startButton.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            startButton.Location = new Point(12, 290);
            startButton.Name = "startButton";
            startButton.Size = new Size(361, 46);
            startButton.TabIndex = 5;
            startButton.Text = "Start";
            startButton.UseVisualStyleBackColor = true;
            startButton.Click += startButton_Click;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // timer2
            // 
            timer2.Interval = 1;
            timer2.Tick += timer2_Tick;
            // 
            // menuButton
            // 
            menuButton.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            menuButton.Location = new Point(12, 342);
            menuButton.Name = "menuButton";
            menuButton.Size = new Size(361, 48);
            menuButton.TabIndex = 7;
            menuButton.Text = "Back to Main Menu";
            menuButton.UseVisualStyleBackColor = true;
            menuButton.Click += menuButton_Click;
            // 
            // button1
            // 
            button1.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(15, 190);
            button1.Name = "button1";
            button1.Size = new Size(355, 43);
            button1.TabIndex = 8;
            button1.Text = "Check!";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(382, 413);
            Controls.Add(button1);
            Controls.Add(menuButton);
            Controls.Add(startButton);
            Controls.Add(clueTb);
            Controls.Add(guessTb);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(timerLabel);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label timerLabel;
        private Label label1;
        private Label label2;
        private TextBox guessTb;
        private TextBox clueTb;
        private Button startButton;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private Button menuButton;
        private Button button1;
    }
}