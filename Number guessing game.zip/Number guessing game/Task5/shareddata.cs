﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task5
{
    static class Shareddata
    {
        public static int minNumber, maxNumber, time;
    }
}
