﻿namespace Task5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            minTb = new TextBox();
            label3 = new Label();
            maxTb = new TextBox();
            label4 = new Label();
            startButton = new Button();
            exitButton = new Button();
            comboBox1 = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(27, 18);
            label1.Name = "label1";
            label1.Size = new Size(324, 29);
            label1.TabIndex = 0;
            label1.Text = "Number Guessing Game";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(27, 98);
            label2.Name = "label2";
            label2.Size = new Size(69, 29);
            label2.TabIndex = 1;
            label2.Text = "Min:";
            // 
            // minTb
            // 
            minTb.Location = new Point(179, 96);
            minTb.Name = "minTb";
            minTb.Size = new Size(198, 31);
            minTb.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(27, 214);
            label3.Name = "label3";
            label3.Size = new Size(139, 29);
            label3.TabIndex = 3;
            label3.Text = "Difficulty:";
            // 
            // maxTb
            // 
            maxTb.Location = new Point(179, 154);
            maxTb.Name = "maxTb";
            maxTb.Size = new Size(198, 31);
            maxTb.TabIndex = 6;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(27, 156);
            label4.Name = "label4";
            label4.Size = new Size(76, 29);
            label4.TabIndex = 5;
            label4.Text = "Max:";
            // 
            // startButton
            // 
            startButton.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            startButton.Location = new Point(34, 263);
            startButton.Name = "startButton";
            startButton.Size = new Size(343, 46);
            startButton.TabIndex = 7;
            startButton.Text = "Start";
            startButton.UseVisualStyleBackColor = true;
            startButton.Click += startButton_Click;
            // 
            // exitButton
            // 
            exitButton.Font = new Font("MS Reference Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitButton.Location = new Point(34, 325);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(343, 46);
            exitButton.TabIndex = 8;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            exitButton.Click += exitButton_Click;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("MS Reference Sans Serif", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Easy", "Medium ", "Hard" });
            comboBox1.Location = new Point(175, 213);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(202, 31);
            comboBox1.TabIndex = 9;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(392, 371);
            Controls.Add(comboBox1);
            Controls.Add(exitButton);
            Controls.Add(startButton);
            Controls.Add(maxTb);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(minTb);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox minTb;
        private Label label3;
        private TextBox maxTb;
        private Label label4;
        private Button startButton;
        private Button exitButton;
        private ComboBox comboBox1;
    }
}